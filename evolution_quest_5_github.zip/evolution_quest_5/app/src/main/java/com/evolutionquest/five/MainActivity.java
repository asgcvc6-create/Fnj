package com.evolutionquest.five;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final String ASSET_GAME_URL = "file:///android_asset/www/index.html";
    private static final String UPDATE_MARKER = "EVOLUTION_QUEST_5_UPDATE_FILE";
    private static final String SAVE_KEY_MARKER = "EvolutionFiveSaveV1";
    private static final String PREFS_NAME = "evolution_quest_updates";
    private static final String KEY_PENDING_SAVE = "pending_save_base64";
    private static final String KEY_UPDATE_PENDING = "update_pending_verification";
    private static final int REQUEST_UPDATE_FILE = 4105;
    private static final int MAX_UPDATE_BYTES = 3 * 1024 * 1024;
    private static final int MAX_DOWNLOAD_BYTES = 25 * 1024 * 1024;
    private static final int MAX_EXTRACTED_BYTES = 50 * 1024 * 1024;
    private static final String UPDATE_SITE_ASSET = "update_site_url.txt";
    private static final String FALLBACK_UPDATE_SITE_URL = "https://soft-king-6710.asgcvc6.workers.dev/";
    private static final String KEY_UPDATE_SITE_URL = "update_site_url";
    private static final String KEY_INSTALLED_GAME_VERSION = "installed_game_version";
    private static final String KEY_FORCE_WEB_DOWNLOAD = "force_web_download";
    private static final String KEY_AUTO_UPDATE_ENABLED = "auto_update_enabled";
    private static final long AUTO_UPDATE_FALLBACK_DELAY_MS = 1400L;

    private WebView webView;
    private boolean recoveredFailedUpdate = false;
    private EditText siteUrlInput;
    private ProgressBar downloadProgress;
    private TextView downloadStatus;
    private TextView downloadDetail;
    private Button downloadButton;
    private Button startWithoutDownloadButton;
    private CheckBox autoUpdateCheckBox;
    private volatile boolean downloading = false;
    private volatile boolean automaticDownloadActive = false;
    private volatile boolean autoUpdateCancelled = false;
    private volatile boolean autoUpdateInstallStarted = false;
    private final Object autoUpdateLock = new Object();
    private boolean gameLaunched = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        recoverFailedUpdateIfNeeded();

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        enableImmersiveFullscreen();

        boolean forceDownload = prefs().getBoolean(KEY_FORCE_WEB_DOWNLOAD, false);
        if (forceDownload) {
            prefs().edit().putBoolean(KEY_FORCE_WEB_DOWNLOAD, false).apply();
        }

        boolean hasLocalGame = isValidUpdateFile(updateFile());
        if (forceDownload || !hasLocalGame) {
            showDownloader(forceDownload);
        } else if (shouldRunAutoUpdateCheck()) {
            showAutoUpdateSplash();
        } else {
            launchGame();
        }
    }

    private void enableImmersiveFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams attrs = getWindow().getAttributes();
            attrs.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(attrs);
        }
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enableImmersiveFullscreen();
        }
    }

    private void launchGame() {
        if (isFinishing() || gameLaunched) {
            return;
        }
        gameLaunched = true;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (webView == null) {
            webView = new WebView(this);
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setAllowFileAccessFromFileURLs(false);
            settings.setAllowUniversalAccessFromFileURLs(false);
            // Updates are downloaded natively once; the downloaded game itself stays local.
            settings.setBlockNetworkLoads(true);
            settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
            settings.setMediaPlaybackRequiresUserGesture(false);
            webView.addJavascriptInterface(new UpdateBridge(), "AndroidUpdateBridge");
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    Uri uri = request.getUrl();
                    String scheme = uri == null ? null : uri.getScheme();
                    if ("file".equals(scheme)
                            || "blob".equals(scheme)
                            || "data".equals(scheme)
                            || "about".equals(scheme)) {
                        return false;
                    }
                    Toast.makeText(MainActivity.this,
                            "اللعبة المنزلة تعمل محليًا؛ تم حظر رابط خارجي",
                            Toast.LENGTH_SHORT).show();
                    return true;
                }
            });
        }
        setContentView(webView);
        webView.clearCache(true);
        webView.loadUrl(initialGameUrl());

        if (recoveredFailedUpdate) {
            Toast.makeText(this,
                    "تعذر تشغيل التحديث الأخير، وتمت العودة إلى النسخة السابقة",
                    Toast.LENGTH_LONG).show();
            recoveredFailedUpdate = false;
        }
    }


    private boolean isAutoUpdateEnabled() {
        return prefs().getBoolean(KEY_AUTO_UPDATE_ENABLED, true);
    }

    private boolean shouldRunAutoUpdateCheck() {
        if (!isAutoUpdateEnabled()) {
            return false;
        }
        String url = savedUpdateSiteUrl();
        // Automatic version checks need a folder URL containing version.json.
        // A direct game.zip URL remains available from the manual downloader.
        return !isExampleUrl(url) && !isDirectFileUrl(url);
    }

    private void showAutoUpdateSplash() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        autoUpdateCancelled = false;
        autoUpdateInstallStarted = false;
        automaticDownloadActive = true;
        siteUrlInput = null;
        downloadButton = null;
        autoUpdateCheckBox = null;

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(0xFF07182B);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setPadding(dp(24), dp(32), dp(24), dp(28));
        scrollView.addView(layout, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        layout.addView(makeText("🦠", 52, false, Color.WHITE));
        addGap(layout, 8);
        layout.addView(makeText("رحلة التطور: المراحل الخمس", 25, true, Color.WHITE));
        addGap(layout, 10);
        layout.addView(makeText("🔄 التحديث التلقائي مفعّل", 17, true, 0xFF9DFFB0));
        addGap(layout, 8);

        String installedVersion = prefs().getString(KEY_INSTALLED_GAME_VERSION, "");
        String localText = "النسخة الحالية: "
                + (installedVersion == null || installedVersion.isEmpty() ? "موجودة على الجهاز" : installedVersion);
        layout.addView(makeText(localText, 14, true, 0xFFFFE9A8));
        addGap(layout, 16);

        downloadProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        downloadProgress.setMax(100);
        downloadProgress.setIndeterminate(true);
        layout.addView(downloadProgress, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        addGap(layout, 8);

        downloadDetail = makeText("جارٍ التحقق من موقع التحديثات…", 15, true, Color.WHITE);
        layout.addView(downloadDetail);
        addGap(layout, 6);
        downloadStatus = makeText(
                "إذا وُجد إصدار أحدث فسيتم تنزيله وتثبيته ثم بدء اللعب تلقائيًا. إذا لم يوجد تحديث أو انقطع الإنترنت فستبدأ النسخة الحالية.",
                14, false, 0xFFDCEFFF);
        layout.addView(downloadStatus);
        addGap(layout, 18);

        startWithoutDownloadButton = new Button(this);
        startWithoutDownloadButton.setText("▶️ اللعب الآن بالنسخة الحالية دون انتظار");
        startWithoutDownloadButton.setOnClickListener(v -> {
            synchronized (autoUpdateLock) {
                if (autoUpdateInstallStarted) {
                    Toast.makeText(MainActivity.this,
                            "جارٍ تثبيت التحديث، انتظر لحظة…",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                autoUpdateCancelled = true;
            }
            launchGame();
        });
        layout.addView(startWithoutDownloadButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(scrollView);
        scrollView.postDelayed(() -> {
            if (!isFinishing() && !autoUpdateCancelled && !downloading) {
                startWebsiteDownload(true);
            }
        }, 250);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView makeText(String text, float sizeSp, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER);
        if (bold) {
            view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        }
        return view;
    }

    private void addGap(LinearLayout layout, int heightDp) {
        View gap = new View(this);
        gap.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp)));
        layout.addView(gap);
    }

    private void showDownloader(boolean forced) {
        gameLaunched = false;
        automaticDownloadActive = false;
        autoUpdateCancelled = false;
        autoUpdateInstallStarted = false;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(0xFF07182B);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setPadding(dp(24), dp(28), dp(24), dp(28));
        scrollView.addView(layout, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView icon = makeText("🦠", 52, false, Color.WHITE);
        layout.addView(icon);
        addGap(layout, 8);
        layout.addView(makeText("رحلة التطور: المراحل الخمس", 25, true, Color.WHITE));
        addGap(layout, 8);
        layout.addView(makeText(
                "سيتم تنزيل بقية ملفات اللعبة من موقع التحديثات، ثم تبدأ اللعبة تلقائيًا. بعد اكتمال التنزيل يمكنك اللعب دون إنترنت.",
                16, false, 0xFFDCEFFF));
        addGap(layout, 10);

        String installedVersion = prefs().getString(KEY_INSTALLED_GAME_VERSION, "");
        boolean hasLocalGame = isValidUpdateFile(updateFile());
        String localText = hasLocalGame
                ? "النسخة المنزلة حاليًا: " + (installedVersion == null || installedVersion.isEmpty() ? "موجودة" : installedVersion)
                : "لا توجد ملفات لعبة منزلة بعد";
        layout.addView(makeText(localText, 14, true, 0xFFFFE9A8));
        addGap(layout, 10);

        autoUpdateCheckBox = new CheckBox(this);
        autoUpdateCheckBox.setText("🔄 تحديث تلقائي عند فتح التطبيق");
        autoUpdateCheckBox.setTextColor(Color.WHITE);
        autoUpdateCheckBox.setTextSize(14);
        autoUpdateCheckBox.setChecked(isAutoUpdateEnabled());
        autoUpdateCheckBox.setOnCheckedChangeListener((buttonView, isChecked) ->
                prefs().edit().putBoolean(KEY_AUTO_UPDATE_ENABLED, isChecked).apply());
        layout.addView(autoUpdateCheckBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        addGap(layout, 14);

        TextView label = makeText("رابط موقع التحديثات (HTTPS) أو رابط ZIP مباشر", 14, true, Color.WHITE);
        label.setGravity(Gravity.START);
        layout.addView(label);
        addGap(layout, 6);

        siteUrlInput = new EditText(this);
        siteUrlInput.setSingleLine(true);
        siteUrlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        siteUrlInput.setText(savedUpdateSiteUrl());
        siteUrlInput.setSelection(siteUrlInput.getText().length());
        siteUrlInput.setHint("https://your-site.example/evolution-quest-5/");
        siteUrlInput.setTextColor(Color.WHITE);
        siteUrlInput.setHintTextColor(0xFF8FAECC);
        siteUrlInput.setBackgroundColor(0xFF10243A);
        siteUrlInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        layout.addView(siteUrlInput, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        addGap(layout, 14);

        downloadButton = new Button(this);
        downloadButton.setText(hasLocalGame ? "⬇️ التحقق من تحديث الموقع وتنزيله" : "⬇️ تنزيل ملفات اللعبة وبدء اللعب");
        downloadButton.setOnClickListener(v -> startWebsiteDownload());
        layout.addView(downloadButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        addGap(layout, 14);

        downloadProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        downloadProgress.setMax(100);
        downloadProgress.setProgress(0);
        layout.addView(downloadProgress, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        addGap(layout, 8);

        downloadDetail = makeText("0% — 0.00 / 0.00 MB", 15, true, Color.WHITE);
        layout.addView(downloadDetail);
        addGap(layout, 6);
        downloadStatus = makeText(
                forced ? "جارٍ تجهيز التحقق من موقع التحديثات…"
                        : "اضغط زر التنزيل عند اتصالك بالإنترنت.",
                14, false, 0xFFDCEFFF);
        layout.addView(downloadStatus);
        addGap(layout, 18);

        startWithoutDownloadButton = new Button(this);
        startWithoutDownloadButton.setText(hasLocalGame
                ? "▶️ ابدأ اللعبة المنزلة دون تحديث"
                : "▶️ تشغيل النسخة الاحتياطية المدمجة دون تنزيل");
        startWithoutDownloadButton.setOnClickListener(v -> {
            if (!downloading) {
                launchGame();
            }
        });
        layout.addView(startWithoutDownloadButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        addGap(layout, 14);
        layout.addView(makeText(
                "يجب أن يحتوي موقعك على version.json و game.zip. ارفع مجلد update_site المرفق بالمشروع إلى موقع HTTPS ثم ضع رابطه هنا مرة واحدة وسيتم حفظه. للتحديث التلقائي استخدم رابط المجلد نفسه، وليس رابط game.zip المباشر.",
                12, false, 0xFFA9C8DF));

        setContentView(scrollView);

        String configuredUrl = siteUrlInput.getText().toString().trim();
        if (isExampleUrl(configuredUrl)) {
            setDownloadUi(0, "استبدل رابط المثال برابط موقع التحديثات الحقيقي أولًا.",
                    "0% — بانتظار رابط موقعك");
        } else {
            scrollView.postDelayed(() -> {
                if (!isFinishing() && !downloading) {
                    startWebsiteDownload();
                }
            }, 400);
        }
    }

    private void setDownloadUi(final int percent, final String status, final String detail) {
        runOnUiThread(() -> {
            if (downloadProgress != null) {
                downloadProgress.setIndeterminate(percent < 0);
                if (percent >= 0) {
                    downloadProgress.setProgress(Math.max(0, Math.min(100, percent)));
                }
            }
            if (downloadStatus != null && status != null) {
                downloadStatus.setText(status);
            }
            if (downloadDetail != null && detail != null) {
                downloadDetail.setText(detail);
            }
        });
    }

    private void setDownloaderEnabled(final boolean enabled) {
        runOnUiThread(() -> {
            if (downloadButton != null) downloadButton.setEnabled(enabled);
            if (startWithoutDownloadButton != null) {
                startWithoutDownloadButton.setEnabled(enabled || automaticDownloadActive);
            }
            if (siteUrlInput != null) siteUrlInput.setEnabled(enabled);
            if (autoUpdateCheckBox != null) autoUpdateCheckBox.setEnabled(enabled);
        });
    }

    private String readBundledUpdateSiteUrl() {
        try (InputStream in = getAssets().open(UPDATE_SITE_ASSET)) {
            String text = new String(readAllBytes(in), StandardCharsets.UTF_8);
            for (String line : text.split("\\R")) {
                String value = line.trim();
                if (!value.isEmpty() && !value.startsWith("#")) {
                    return value;
                }
            }
        } catch (Exception ignored) {
        }
        return FALLBACK_UPDATE_SITE_URL;
    }

    private String savedUpdateSiteUrl() {
        String saved = prefs().getString(KEY_UPDATE_SITE_URL, "");
        return saved == null || saved.trim().isEmpty() ? readBundledUpdateSiteUrl() : saved.trim();
    }

    private boolean isExampleUrl(String raw) {
        return raw == null || raw.contains("example.com") || raw.contains("your-site.example");
    }

    private boolean isDirectFileUrl(String raw) {
        if (raw == null) return false;
        String lower = raw.toLowerCase(Locale.US);
        int query = lower.indexOf('?');
        if (query >= 0) lower = lower.substring(0, query);
        return lower.endsWith(".zip") || lower.endsWith(".html") || lower.endsWith(".htm");
    }

    private String validatedHttpsUrl(String raw) throws Exception {
        String value = raw == null ? "" : raw.trim();
        if (value.isEmpty()) {
            throw new IOException("رابط موقع التحديثات فارغ");
        }
        if (!value.contains("://")) {
            value = "https://" + value;
        }
        URL url = new URL(value);
        if (!"https".equalsIgnoreCase(url.getProtocol())) {
            throw new IOException("استخدم رابط HTTPS آمنًا لموقع التحديثات");
        }
        if (url.getHost() == null || url.getHost().isEmpty()) {
            throw new IOException("رابط موقع التحديثات غير صالح");
        }
        return url.toString();
    }

    private String normalizedBaseUrl(String raw) throws Exception {
        String value = validatedHttpsUrl(raw);
        String lower = value.toLowerCase(Locale.US);
        if (lower.endsWith("version.json")) {
            value = value.substring(0, value.length() - "version.json".length());
            lower = value.toLowerCase(Locale.US);
        }
        if (!lower.endsWith("/")) {
            value += "/";
        }
        return value;
    }

    private static final class RemoteGameInfo {
        String version = "";
        String fileUrl = "";
        String sha256 = "";
    }

    private HttpURLConnection openConnection(String urlString) throws Exception {
        return openConnection(urlString, false);
    }

    private HttpURLConnection openConnection(String urlString, boolean quickCheck) throws Exception {
        URL url = new URL(validatedHttpsUrl(urlString));
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setInstanceFollowRedirects(true);
        connection.setUseCaches(false);
        connection.setConnectTimeout(quickCheck ? 5000 : 15000);
        connection.setReadTimeout(quickCheck ? 7000 : 30000);
        connection.setRequestProperty("User-Agent", "EvolutionQuest5-Downloader/1.3");
        connection.setRequestProperty("Accept", "*/*");
        connection.setRequestProperty("Cache-Control", "no-cache");
        connection.setRequestProperty("Pragma", "no-cache");
        return connection;
    }

    private String fetchText(String urlString) throws Exception {
        return fetchText(urlString, false);
    }

    private String fetchText(String urlString, boolean quickCheck) throws Exception {
        HttpURLConnection connection = openConnection(urlString, quickCheck);
        try {
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) {
                throw new IOException("الموقع رد بالحالة " + code + " عند طلب version.json");
            }
            try (InputStream in = new BufferedInputStream(connection.getInputStream());
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                    if (out.size() > 65536) {
                        throw new IOException("ملف version.json أكبر من اللازم");
                    }
                }
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally {
            connection.disconnect();
        }
    }

    private RemoteGameInfo fetchRemoteInfo(String raw) throws Exception {
        return fetchRemoteInfo(raw, false);
    }

    private RemoteGameInfo fetchRemoteInfo(String raw, boolean quickCheck) throws Exception {
        RemoteGameInfo info = new RemoteGameInfo();
        if (isDirectFileUrl(raw)) {
            info.fileUrl = validatedHttpsUrl(raw);
            return info;
        }
        String baseUrl = normalizedBaseUrl(raw);
        setDownloadUi(-1, "جارٍ الاتصال بموقع التحديثات وقراءة version.json…", "جارٍ الاتصال…");
        String versionUrl = baseUrl + "version.json?t=" + System.currentTimeMillis();
        JSONObject json = new JSONObject(fetchText(versionUrl, quickCheck));
        info.version = json.optString("version", "").trim();
        String file = json.optString("file", "game.zip").trim();
        info.fileUrl = validatedHttpsUrl(new URL(new URL(baseUrl), file).toString());
        if (!info.version.isEmpty() && !info.fileUrl.contains("?")) {
            // Avoid a stale CDN copy of game.zip after version.json changes.
            info.fileUrl += "?v=" + Uri.encode(info.version);
        }
        info.sha256 = json.optString("sha256", "").trim().toLowerCase(Locale.US);
        return info;
    }

    private int parseVersionPart(String value) {
        if (value == null) return 0;
        int end = 0;
        while (end < value.length() && Character.isDigit(value.charAt(end))) {
            end++;
        }
        if (end == 0) return 0;
        try {
            return Integer.parseInt(value.substring(0, end));
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    private int compareVersions(String left, String right) {
        String[] leftParts = (left == null ? "" : left.trim()).split("\\.");
        String[] rightParts = (right == null ? "" : right.trim()).split("\\.");
        int length = Math.max(leftParts.length, rightParts.length);
        for (int i = 0; i < length; i++) {
            int a = i < leftParts.length ? parseVersionPart(leftParts[i]) : 0;
            int b = i < rightParts.length ? parseVersionPart(rightParts[i]) : 0;
            if (a != b) return Integer.compare(a, b);
        }
        return 0;
    }

    private String installedGameVersion() {
        String saved = prefs().getString(KEY_INSTALLED_GAME_VERSION, "");
        if (saved != null && !saved.trim().isEmpty()) {
            return saved.trim();
        }
        try (InputStream in = new FileInputStream(updateFile())) {
            String html = new String(readAllBytes(in), StandardCharsets.UTF_8);
            int marker = html.indexOf("name=\"game-version\"");
            int content = marker < 0 ? -1 : html.indexOf("content=\"", marker);
            if (content >= 0) {
                int start = content + "content=\"".length();
                int end = html.indexOf('"', start);
                if (end > start) {
                    String version = html.substring(start, end).trim();
                    if (!version.isEmpty()) {
                        prefs().edit().putString(KEY_INSTALLED_GAME_VERSION, version).apply();
                        return version;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private String formatMb(long bytes) {
        return String.format(Locale.US, "%.2f", bytes / 1000000.0);
    }

    private String sha256Hex(byte[] digest) {
        StringBuilder out = new StringBuilder(digest.length * 2);
        for (byte b : digest) {
            out.append(String.format(Locale.US, "%02x", b & 0xff));
        }
        return out.toString();
    }

    private File downloadToCache(String urlString, String expectedSha256) throws Exception {
        File output = new File(getCacheDir(), "game-download.tmp");
        deleteQuietly(output);
        HttpURLConnection connection = openConnection(urlString);
        try {
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) {
                throw new IOException("الموقع رد بالحالة " + code + " عند تنزيل ملفات اللعبة");
            }
            long total = connection.getContentLengthLong();
            if (total > MAX_DOWNLOAD_BYTES) {
                throw new IOException("حزمة ملفات اللعبة أكبر من 25MB");
            }
            MessageDigest digest = expectedSha256 == null || expectedSha256.isEmpty()
                    ? null : MessageDigest.getInstance("SHA-256");
            long downloaded = 0;
            long lastUi = 0;
            try (InputStream in = new BufferedInputStream(connection.getInputStream());
                 OutputStream out = new BufferedOutputStream(new FileOutputStream(output))) {
                byte[] buffer = new byte[16384];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    if (automaticDownloadActive && autoUpdateCancelled) {
                        throw new IOException("Auto update cancelled by player");
                    }
                    out.write(buffer, 0, read);
                    if (digest != null) digest.update(buffer, 0, read);
                    downloaded += read;
                    if (downloaded > MAX_DOWNLOAD_BYTES) {
                        throw new IOException("حزمة ملفات اللعبة أكبر من 25MB");
                    }
                    long now = System.currentTimeMillis();
                    if (now - lastUi > 120) {
                        lastUi = now;
                        if (total > 0) {
                            int percent = (int) Math.min(100, downloaded * 100 / total);
                            setDownloadUi(percent, "جارٍ تنزيل بقية ملفات اللعبة من موقع التحديثات…",
                                    percent + "% — " + formatMb(downloaded) + " / " + formatMb(total) + " MB");
                        } else {
                            setDownloadUi(-1, "جارٍ تنزيل بقية ملفات اللعبة من موقع التحديثات…",
                                    "تم تنزيل " + formatMb(downloaded) + " MB…");
                        }
                    }
                }
                out.flush();
            }
            if (digest != null) {
                String actual = sha256Hex(digest.digest());
                if (!actual.equalsIgnoreCase(expectedSha256)) {
                    deleteQuietly(output);
                    throw new IOException("بصمة SHA-256 للملف المنزل غير مطابقة");
                }
            }
            if (total > 0) {
                setDownloadUi(100, "اكتمل تنزيل الملفات — جارٍ فكها وتثبيتها…",
                        "100% — " + formatMb(output.length()) + " MB");
            }
            return output;
        } finally {
            connection.disconnect();
        }
    }

    private boolean isZipFile(File file) {
        try (InputStream in = new FileInputStream(file)) {
            return in.read() == 'P' && in.read() == 'K';
        } catch (Exception ignored) {
            return false;
        }
    }

    private void deleteRecursive(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) deleteRecursive(child);
            }
        }
        //noinspection ResultOfMethodCallIgnored
        file.delete();
    }

    private void copyDirectory(File from, File to) throws IOException {
        if (!to.exists() && !to.mkdirs()) {
            throw new IOException("Cannot create game directory");
        }
        File[] children = from.listFiles();
        if (children == null) return;
        for (File child : children) {
            File target = new File(to, child.getName());
            if (child.isDirectory()) copyDirectory(child, target);
            else copyFile(child, target);
        }
    }

    private File findIndexFile(File dir) {
        File direct = new File(dir, "index.html");
        if (direct.isFile()) return direct;
        File[] children = dir.listFiles();
        if (children == null) return null;
        for (File child : children) {
            if (child.isDirectory()) {
                File found = findIndexFile(child);
                if (found != null) return found;
            }
        }
        return null;
    }

    private void installHtmlBytes(byte[] bytes, String remoteVersion) throws IOException {
        String html = new String(bytes, StandardCharsets.UTF_8);
        if (!isValidUpdateHtml(html)) {
            throw new IOException("ملف HTML المنزل ليس نسخة صالحة من هذه اللعبة");
        }
        File dir = wwwDir();
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("Cannot create game directory");
        }
        File update = updateFile();
        File backup = backupFile();
        File temp = new File(dir, "index.html.tmp");
        if (isValidUpdateFile(update)) copyFile(update, backup);
        else deleteQuietly(backup);
        try (OutputStream out = new FileOutputStream(temp)) {
            out.write(bytes);
            out.flush();
        }
        if (update.exists() && !update.delete()) {
            throw new IOException("Cannot replace previous game file");
        }
        if (!temp.renameTo(update)) {
            copyFile(temp, update);
            deleteQuietly(temp);
        }
        if (!isValidUpdateFile(update)) {
            deleteQuietly(update);
            if (backup.exists() && !backup.renameTo(update)) {
                copyFile(backup, update);
                deleteQuietly(backup);
            }
            throw new IOException("فشل التحقق من ملف اللعبة بعد تثبيته");
        }
        prefs().edit()
                .putBoolean(KEY_UPDATE_PENDING, true)
                .putString(KEY_INSTALLED_GAME_VERSION, remoteVersion == null ? "" : remoteVersion)
                .apply();
    }

    private void installDownloadedFile(File downloaded, String remoteVersion) throws Exception {
        if (!isZipFile(downloaded)) {
            try (InputStream in = new FileInputStream(downloaded)) {
                installHtmlBytes(readAllBytes(in), remoteVersion);
            }
            return;
        }

        File staging = new File(getFilesDir(), "www_staging");
        deleteRecursive(staging);
        if (!staging.mkdirs()) {
            throw new IOException("Cannot create staging directory");
        }
        long extractedTotal = 0;
        String stagingCanonical = staging.getCanonicalPath();
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(new FileInputStream(downloaded)))) {
            ZipEntry entry;
            byte[] buffer = new byte[16384];
            while ((entry = zip.getNextEntry()) != null) {
                File target = new File(staging, entry.getName());
                String targetCanonical = target.getCanonicalPath();
                if (!targetCanonical.equals(stagingCanonical)
                        && !targetCanonical.startsWith(stagingCanonical + File.separator)) {
                    throw new IOException("حزمة ZIP تحتوي مسارًا غير آمن");
                }
                if (entry.isDirectory()) {
                    if (!target.exists() && !target.mkdirs()) {
                        throw new IOException("Cannot create extracted directory");
                    }
                } else {
                    File parent = target.getParentFile();
                    if (parent != null && !parent.exists() && !parent.mkdirs()) {
                        throw new IOException("Cannot create extracted directory");
                    }
                    try (OutputStream out = new BufferedOutputStream(new FileOutputStream(target))) {
                        int read;
                        while ((read = zip.read(buffer)) != -1) {
                            out.write(buffer, 0, read);
                            extractedTotal += read;
                            if (extractedTotal > MAX_EXTRACTED_BYTES) {
                                throw new IOException("الملفات المفكوكة أكبر من 50MB");
                            }
                        }
                    }
                }
                zip.closeEntry();
            }
        }

        File index = findIndexFile(staging);
        if (index == null || !isValidUpdateFile(index)) {
            deleteRecursive(staging);
            throw new IOException("حزمة ZIP لا تحتوي index.html صالحًا لهذه اللعبة");
        }
        File sourceRoot = index.getParentFile();
        File current = updateFile();
        File backup = backupFile();
        if (isValidUpdateFile(current)) copyFile(current, backup);
        else deleteQuietly(backup);

        deleteRecursive(wwwDir());
        copyDirectory(sourceRoot, wwwDir());
        deleteRecursive(staging);

        if (!isValidUpdateFile(updateFile())) {
            deleteRecursive(wwwDir());
            if (backup.exists()) {
                if (!wwwDir().mkdirs()) throw new IOException("Cannot restore game directory");
                copyFile(backup, updateFile());
            }
            throw new IOException("فشل التحقق من حزمة اللعبة بعد فكها");
        }
        prefs().edit()
                .putBoolean(KEY_UPDATE_PENDING, true)
                .putString(KEY_INSTALLED_GAME_VERSION, remoteVersion == null ? "" : remoteVersion)
                .apply();
    }

    private void startWebsiteDownload() {
        startWebsiteDownload(false);
    }

    private void startWebsiteDownload(final boolean automatic) {
        if (downloading) return;
        final String rawUrl = automatic
                ? savedUpdateSiteUrl()
                : (siteUrlInput == null ? "" : siteUrlInput.getText().toString().trim());
        if (rawUrl.isEmpty()) {
            if (automatic && isValidUpdateFile(updateFile())) {
                launchGame();
            } else {
                setDownloadUi(0, "اكتب رابط موقع التحديثات أولًا.", "0% — لا يوجد رابط");
            }
            return;
        }
        if (isExampleUrl(rawUrl)) {
            if (automatic && isValidUpdateFile(updateFile())) {
                launchGame();
            } else {
                setDownloadUi(0, "هذا رابط مثال. ارفع مجلد update_site إلى موقعك ثم الصق رابطه الحقيقي هنا.",
                        "0% — بانتظار رابط موقعك");
            }
            return;
        }
        if (automatic && isDirectFileUrl(rawUrl)) {
            // A direct package has no version feed to compare against.
            if (isValidUpdateFile(updateFile())) {
                launchGame();
            } else {
                showDownloader(false);
            }
            return;
        }

        downloading = true;
        automaticDownloadActive = automatic;
        autoUpdateInstallStarted = false;
        if (automatic) {
            autoUpdateCancelled = false;
        }
        setDownloaderEnabled(false);
        setDownloadUi(-1,
                automatic ? "جارٍ التحقق تلقائيًا من وجود تحديث جديد…" : "جارٍ بدء التنزيل من موقع التحديثات…",
                "جارٍ الاتصال…");
        new Thread(() -> {
            try {
                RemoteGameInfo info = fetchRemoteInfo(rawUrl, automatic);
                if (automatic && autoUpdateCancelled) {
                    downloading = false;
                    automaticDownloadActive = false;
                    return;
                }
                String savedValue = isDirectFileUrl(rawUrl) ? validatedHttpsUrl(rawUrl) : normalizedBaseUrl(rawUrl);
                prefs().edit().putString(KEY_UPDATE_SITE_URL, savedValue).apply();

                boolean hasLocalGame = isValidUpdateFile(updateFile());
                String installedVersion = installedGameVersion();
                boolean remoteIsNotNewer = hasLocalGame
                        && !info.version.isEmpty()
                        && !installedVersion.isEmpty()
                        && compareVersions(info.version, installedVersion) <= 0;

                if (remoteIsNotNewer) {
                    setDownloadUi(100, "لديك أحدث نسخة من موقع التحديثات — جارٍ بدء اللعبة…",
                            "100% — النسخة " + installedVersion + " مثبتة");
                } else {
                    if (automatic && autoUpdateCancelled) {
                        downloading = false;
                        automaticDownloadActive = false;
                        return;
                    }
                    if (automatic && hasLocalGame && !info.version.isEmpty()) {
                        setDownloadUi(-1, "وجدنا تحديثًا جديدًا (" + info.version + ") — جارٍ تنزيله تلقائيًا…",
                                "جارٍ بدء تنزيل التحديث…");
                    }
                    File downloaded = downloadToCache(info.fileUrl, info.sha256);
                    synchronized (autoUpdateLock) {
                        if (automatic && autoUpdateCancelled) {
                            deleteQuietly(downloaded);
                            downloading = false;
                            automaticDownloadActive = false;
                            return;
                        }
                        if (automatic) {
                            autoUpdateInstallStarted = true;
                        }
                    }
                    setDownloadUi(100, "جارٍ فك ملفات اللعبة وتثبيتها…", "اكتمل التنزيل — جارٍ التثبيت");
                    installDownloadedFile(downloaded, info.version);
                    deleteQuietly(downloaded);
                    synchronized (autoUpdateLock) {
                        autoUpdateInstallStarted = false;
                    }
                    setDownloadUi(100, "اكتمل تنزيل ملفات اللعبة — جارٍ بدء اللعب…", "100% — تم التثبيت");
                }
                downloading = false;
                automaticDownloadActive = false;
                autoUpdateInstallStarted = false;
                runOnUiThread(() -> {
                    setDownloaderEnabled(true);
                    if (!autoUpdateCancelled && !isFinishing()) {
                        launchGame();
                    }
                });
            } catch (Exception e) {
                downloading = false;
                automaticDownloadActive = false;
                autoUpdateInstallStarted = false;
                if (automatic && autoUpdateCancelled) {
                    return;
                }
                String message = e.getMessage();
                if (message == null || message.trim().isEmpty()) {
                    message = e.getClass().getSimpleName();
                }
                final String shown = message;
                if (automatic && isValidUpdateFile(updateFile())) {
                    setDownloadUi(0, "تعذر التحقق التلقائي من التحديث: " + shown
                                    + "\nسيتم تشغيل النسخة الحالية على الجهاز.",
                            "لا يوجد اتصال أو تعذر الوصول للموقع");
                    setDownloaderEnabled(true);
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        if (!isFinishing() && !autoUpdateCancelled && !gameLaunched) {
                            launchGame();
                        }
                    }, AUTO_UPDATE_FALLBACK_DELAY_MS);
                } else if (automatic) {
                    runOnUiThread(() -> {
                        if (!isFinishing()) {
                            showDownloader(false);
                        }
                    });
                } else {
                    setDownloadUi(0, "تعذر تنزيل ملفات اللعبة: " + shown + "\nتحقق من الإنترنت ومن رابط موقع التحديثات ثم حاول مجددًا.",
                            "فشل التنزيل");
                    setDownloaderEnabled(true);
                }
            }
        }).start();
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }

    private File wwwDir() {
        return new File(getFilesDir(), "www");
    }

    private File updateFile() {
        return new File(wwwDir(), "index.html");
    }

    private File backupFile() {
        return new File(getFilesDir(), "index.backup.html");
    }

    private String initialGameUrl() {
        String url = isValidUpdateFile(updateFile())
                ? Uri.fromFile(updateFile()).toString()
                : ASSET_GAME_URL;
        String pendingSave = prefs().getString(KEY_PENDING_SAVE, "");
        if (pendingSave != null && !pendingSave.isEmpty()) {
            url += "#evo-update-transfer";
        }
        return url;
    }

    /**
     * An imported page must call markUpdateHealthy() after its JavaScript has
     * successfully booted. If the app is opened again while verification is
     * still pending, the previous known-good copy is restored instead.
     */
    private void recoverFailedUpdateIfNeeded() {
        if (!prefs().getBoolean(KEY_UPDATE_PENDING, false)) {
            return;
        }
        deleteQuietly(updateFile());
        File backup = backupFile();
        if (backup.exists()) {
            File update = updateFile();
            File parent = update.getParentFile();
            if (parent != null && !parent.exists()) {
                //noinspection ResultOfMethodCallIgnored
                parent.mkdirs();
            }
            if (!backup.renameTo(update)) {
                try {
                    copyFile(backup, update);
                    deleteQuietly(backup);
                } catch (IOException ignored) {
                    deleteQuietly(update);
                }
            }
        }
        prefs().edit().putBoolean(KEY_UPDATE_PENDING, false).apply();
        recoveredFailedUpdate = true;
    }

    private boolean isValidUpdateFile(File file) {
        if (file == null || !file.isFile()) {
            return false;
        }
        long length = file.length();
        if (length < 10000 || length > MAX_UPDATE_BYTES) {
            return false;
        }
        try (InputStream in = new FileInputStream(file)) {
            String html = new String(readAllBytes(in), StandardCharsets.UTF_8);
            return isValidUpdateHtml(html);
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean isValidUpdateHtml(String html) {
        if (html == null || html.length() < 10000 || html.length() > MAX_UPDATE_BYTES) {
            return false;
        }
        return html.contains(UPDATE_MARKER)
                && html.contains(SAVE_KEY_MARKER)
                && html.toLowerCase().contains("</html>");
    }

    private byte[] readAllBytes(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
            if (out.size() > MAX_UPDATE_BYTES) {
                throw new IOException("Update file is too large");
            }
        }
        return out.toByteArray();
    }

    private void copyFile(File from, File to) throws IOException {
        File parent = to.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IOException("Cannot create update directory");
        }
        try (InputStream in = new FileInputStream(from);
             OutputStream out = new FileOutputStream(to)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            out.flush();
        }
    }

    private void deleteQuietly(File file) {
        try {
            if (file != null && file.exists()) {
                //noinspection ResultOfMethodCallIgnored
                file.delete();
            }
        } catch (Exception ignored) {
        }
    }

    private void clearPendingSavePreference() {
        prefs().edit().remove(KEY_PENDING_SAVE).apply();
    }

    private void showToast(final String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_UPDATE_FILE) {
            return;
        }
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            clearPendingSavePreference();
            Toast.makeText(this, "تم إلغاء استيراد التحديث", Toast.LENGTH_SHORT).show();
            return;
        }
        final Uri uri = data.getData();
        Toast.makeText(this, "جارٍ فحص ملف التحديث…", Toast.LENGTH_SHORT).show();
        new Thread(() -> installUpdateFromUri(uri)).start();
    }

    private void installUpdateFromUri(Uri uri) {
        try {
            byte[] bytes;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) {
                    throw new IOException("Cannot open selected file");
                }
                bytes = readAllBytes(in);
            }

            String html = new String(bytes, StandardCharsets.UTF_8);
            if (!isValidUpdateHtml(html)) {
                clearPendingSavePreference();
                showToast("هذا الملف ليس تحديثًا صالحًا للعبة رحلة التطور");
                return;
            }

            File dir = wwwDir();
            if (!dir.exists() && !dir.mkdirs()) {
                throw new IOException("Cannot create update directory");
            }
            File update = updateFile();
            File backup = backupFile();
            File temp = new File(dir, "index.html.tmp");

            if (isValidUpdateFile(update)) {
                copyFile(update, backup);
            } else {
                deleteQuietly(backup);
            }

            try (OutputStream out = new FileOutputStream(temp)) {
                out.write(bytes);
                out.flush();
            }

            if (update.exists() && !update.delete()) {
                throw new IOException("Cannot replace previous update");
            }
            if (!temp.renameTo(update)) {
                copyFile(temp, update);
                deleteQuietly(temp);
            }

            if (!isValidUpdateFile(update)) {
                deleteQuietly(update);
                if (backup.exists() && !backup.renameTo(update)) {
                    copyFile(backup, update);
                    deleteQuietly(backup);
                }
                clearPendingSavePreference();
                showToast("فشل تثبيت التحديث، وتم الحفاظ على النسخة السابقة");
                return;
            }

            prefs().edit()
                    .putBoolean(KEY_UPDATE_PENDING, true)
                    .remove(KEY_INSTALLED_GAME_VERSION)
                    .apply();
            final String url = Uri.fromFile(update).toString()
                    + "?v=" + System.currentTimeMillis()
                    + "#evo-update-applied";
            runOnUiThread(() -> {
                if (webView != null) {
                    webView.clearCache(true);
                    webView.loadUrl(url);
                }
                Toast.makeText(MainActivity.this,
                        "تم تثبيت التحديث — جارٍ إعادة تشغيل اللعبة",
                        Toast.LENGTH_SHORT).show();
            });
        } catch (Exception e) {
            clearPendingSavePreference();
            showToast("تعذر تثبيت ملف التحديث");
        }
    }

    private final class UpdateBridge {
        @JavascriptInterface
        public void importUpdate(final String saveBase64) {
            runOnUiThread(() -> {
                if (saveBase64 != null) {
                    prefs().edit().putString(KEY_PENDING_SAVE, saveBase64).apply();
                }
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES,
                        new String[]{"text/html", "text/plain", "application/octet-stream"});
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivityForResult(intent, REQUEST_UPDATE_FILE);
                } catch (Exception e) {
                    clearPendingSavePreference();
                    Toast.makeText(MainActivity.this,
                            "لا يوجد تطبيق ملفات لاختيار التحديث",
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void openWebsiteDownloader(final String saveBase64) {
            if (saveBase64 != null) {
                prefs().edit().putString(KEY_PENDING_SAVE, saveBase64).apply();
            }
            prefs().edit().putBoolean(KEY_FORCE_WEB_DOWNLOAD, true).apply();
            runOnUiThread(() -> recreate());
        }

        @JavascriptInterface
        public void removeUpdate(final String saveBase64) {
            if (saveBase64 != null) {
                prefs().edit().putString(KEY_PENDING_SAVE, saveBase64).apply();
            }
            new Thread(() -> {
                deleteRecursive(wwwDir());
                deleteQuietly(backupFile());
                prefs().edit()
                        .putBoolean(KEY_UPDATE_PENDING, false)
                        .remove(KEY_INSTALLED_GAME_VERSION)
                        .apply();
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this,
                            "تم حذف ملفات اللعبة المنزلة — يمكنك تنزيلها من جديد",
                            Toast.LENGTH_SHORT).show();
                    if (webView != null) {
                        webView.destroy();
                        webView = null;
                    }
                    showDownloader(false);
                });
            }).start();
        }

        @JavascriptInterface
        public boolean isUpdateInstalled() {
            return isValidUpdateFile(updateFile());
        }

        @JavascriptInterface
        public String getPendingSaveBase64() {
            String value = prefs().getString(KEY_PENDING_SAVE, "");
            return value == null ? "" : value;
        }

        @JavascriptInterface
        public void clearPendingSave() {
            clearPendingSavePreference();
        }

        @JavascriptInterface
        public void markUpdateHealthy() {
            if (prefs().getBoolean(KEY_UPDATE_PENDING, false)) {
                prefs().edit().putBoolean(KEY_UPDATE_PENDING, false).apply();
                deleteQuietly(backupFile());
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.getParent() != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        autoUpdateCancelled = true;
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
