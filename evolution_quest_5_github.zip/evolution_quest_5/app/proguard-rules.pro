# Keep the local update bridge callable from the packaged game page after R8 shrinking.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.evolutionquest.five.MainActivity { *; }
-keep class com.evolutionquest.five.MainActivity$UpdateBridge { *; }
