#!/usr/bin/env python3
"""Build update_site/game.zip and version.json from the canonical game HTML."""
from __future__ import annotations

import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GAME = ROOT / "app" / "src" / "main" / "assets" / "www" / "index.html"
SITE = ROOT / "update_site"
ZIP_PATH = SITE / "game.zip"
VERSION_PATH = SITE / "version.json"

html = GAME.read_bytes()
text = html.decode("utf-8")
if "EVOLUTION_QUEST_5_UPDATE_FILE" not in text or "EvolutionFiveSaveV1" not in text:
    raise SystemExit("Game HTML is missing its update/save markers")

match = re.search(r'name="game-version" content="([^"]+)"', text)
version = match.group(1) if match else "unknown"

SITE.mkdir(parents=True, exist_ok=True)
info = zipfile.ZipInfo("index.html", date_time=(2024, 1, 1, 0, 0, 0))
info.compress_type = zipfile.ZIP_DEFLATED
info.external_attr = 0o644 << 16
with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    zf.writestr(info, html)

data = ZIP_PATH.read_bytes()
manifest = {
    "version": version,
    "file": "game.zip",
    "sha256": hashlib.sha256(data).hexdigest(),
    "size": len(data),
    "notes": "Evolution Quest 5 website update package",
}
VERSION_PATH.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Built {ZIP_PATH} ({len(data)} bytes) for game version {version}")
print(f"Wrote {VERSION_PATH}")
